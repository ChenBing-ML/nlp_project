# Homework-week4
## 1. 在BahdanauAttentionCoverage类中完成与coverage相关的代码定义

## 2. 完成Pointer类中Pgen系数的定义

## 3. 在PGN model中补充代码，完成整个模型的搭建

## 4. 在loss中完成_coverage_loss的代码



通过上述重要模型代码补全，可以顺利跑通PGN网络

测试代码不要调整可以参考使用